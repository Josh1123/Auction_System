﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


////////////////////////////////////
// Created by Ryan Williams
//
// Bid Class to allow for the easy 
// storage of bids that are 
// placed on an auction, since
// no changes are made to a bid
// after creation no mutators
// are needed
/////////////////////////////////////

namespace Auction_System
{
    public class Bid
    {
        private double amount;
        private Buyer who;
        private DateTime when;

        public Bid()
        {

        }

        public Bid(double pamount, Buyer pwho, DateTime pwhen)
        {
            amount = pamount;
            who = pwho;
            when = pwhen;
        }

        ~Bid()
        {
            
        }

        public double getBid()
        {
            return amount;
        }

        public Buyer whoBid()
        {
            return who;
        }

        public DateTime getDate()
        {
            return when;
        }

    }
}
