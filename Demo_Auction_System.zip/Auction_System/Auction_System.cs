﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

/////////////////////////////
//       Created By 
//      Joshua Phelan
/////////////////////////////

//////////////////////////////////////
// The auctin_system is used 
// to act as a holder class
// for the data until it is
// stored to file and will also
// act to populate the data 
// structures using those files.
// 
// Will also serve to inform the 
// users of any successful purchases
//////////////////////////////////////

namespace Auction_System
{
    public class Auction_System
    {
        /// <summary>
        /// Lists added to allow the data to be saved to files and will allow the data to be read back into the system
        /// Extra function have been added to implement the lists fully
        /// </summary>
        private List<Auction> list_of_auctions = new List<Auction>();
        private List<Buyer> list_of_buyers = new List<Buyer>();
        private List<Seller> list_of_sellers = new List<Seller>();

        public Auction_System()
        {
            
        }

        ~Auction_System()
        {
            
        }
        
        /// <summary>
        /// Created By Joshua Phelan
        /// Function that will return an auction
        /// to a buyer depending on which number
        /// auction they want to bid on
        /// and then allow them to place a bid on that auction
        /// </summary>
        /// <param name="auctionNumber"></param>
        /// <returns></returns>
        public Auction PlaceAuction(int auctionNumber)
        {
                Auction newAuction = new Auction();
                newAuction = list_of_auctions.ElementAt(auctionNumber - 1);
                return newAuction;
        }

        public void BrowseAuction()
        {
            ///////////////////////////////
            // Written By Ryan Williams
            ///////////////////////////////
            int i = 0;
            Console.Clear();
            Console.WriteLine("Welcome User!");
            Console.WriteLine();
            Console.WriteLine("The following auction is in progress!");
            Console.WriteLine();
           foreach(Auction auc in list_of_auctions)
           {
               i++;
               Console.WriteLine("Auction " + i);
               auc.outputAuction();
           }
           Console.ReadLine();
        }

        public void SetupAuction(ref Seller curr_seller)
        {
            ////////////////////////////////////
            // Started By Ryan Williams -
            // Finished by Joshua Phelan 
            // to save created auction to 
            // auction list in auction systen
            ////////////////////////////////////
            string description;
            double startPrice;
            double reservePrice;
            DateTime closeDate;
            bool valid = false;

            while(!valid)
            {
                Console.Clear();
                Console.WriteLine("Enter description of item");
                description = Console.ReadLine();
                Console.WriteLine("Reserve Price = ");
                reservePrice = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Starting Price = ");
                startPrice = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Close Date = ");
                closeDate = Convert.ToDateTime(Console.ReadLine());
                if (closeDate <= DateTime.Now.AddDays(7.0f) && closeDate >= DateTime.Now)
                {
                    valid = true;
                }
                else
                {
                    Console.WriteLine("Invalid Date, close Date must at least be today and less or equal to 7 days in advance");
                }
                if(valid)
                {
                    Console.WriteLine("Press ENTER to list item"); //list item, write to file
                    Console.ReadLine();
                    Auction new_auction = new Auction(description, startPrice, reservePrice, closeDate);
                    Console.WriteLine("Item has been listed in auction");
                    curr_seller.addPending(new_auction);        //Stores the created auction in the sellers list of pending auctions
                }
            }
            Console.WriteLine();
            Console.WriteLine("Press ESC to return to auction menu");
            while (Console.ReadKey().Key != ConsoleKey.Escape) { }
        }

        /// <summary>
        /// Add User functions have been added 
        /// to allow buyers and sellers to be added 
        /// to a list that will be written to file
        /// allowing for multpile users to be saved 
        /// to file and will be read from file on
        /// system launch
        /// </summary>
        /// <param name="pbuyer"></param>
        public void addBuyer(Buyer pbuyer)
        {
            list_of_buyers.Add(pbuyer);
        }

        public void addSeller(Seller pSeller)
        {
            list_of_sellers.Add(pSeller);
        }
        
        public void addAuction(Auction pauction)
        {
            list_of_auctions.Add(pauction);
        }
        /// <summary>
        /// Logon user has been designed to call on 
        /// logon buyer or seller dependant on 
        /// whether the user is a buyer or seller
        /// the code was split to make code more readable 
        /// and to reduce the amount of code needed
        /// </summary>
        /// <param name="pcurrentBuyer"></param>
        /// <param name="pcurrentSeller"></param>
        public void logonUser(ref Buyer pcurrentBuyer, ref Seller pcurrentSeller)
        {
            ///////////////////////////////
            // Written By Joshua Phelan
            // used Ryans code as a base
            // for switch statement
            ///////////////////////////////
            string choice;
            bool valid_choice = false;
            while (!valid_choice)
            {
                Console.Clear();
                Console.WriteLine("Buyer(b/B) or Seller(s/S)?");
                choice = Console.ReadLine();
                if (choice == "s" || choice == "S" || choice == "b" || choice == "B")
                    valid_choice = true;
                switch (choice) //Switch menu
                {
                    case "s":
                        pcurrentSeller = logonSeller(ref pcurrentBuyer,ref pcurrentSeller);
                        break;
                    case "S":
                        pcurrentSeller = logonSeller(ref pcurrentBuyer, ref pcurrentSeller);
                        break;
                    case "b":
                        pcurrentBuyer = logonBuyer(ref pcurrentBuyer, ref pcurrentSeller);
                        break;
                    case "B":
                        pcurrentBuyer = logonBuyer(ref pcurrentBuyer,ref pcurrentSeller);
                        break;
                    default:
                        Console.WriteLine("Invalid Input");
                        Console.ReadLine();
                        break;
                }
            }
        }

        public Buyer logonBuyer(ref Buyer pcurrentBuyer, ref Seller pcurrentSeller)
        {
            ///////////////////////////////
            // Created By Joshua Phelan
            // Done to seperate user logon
            // into smaller functions to  
            // reudce code
            ///////////////////////////////
            bool buyer = false;
            Buyer compBuyer = new Buyer();
            while (!buyer)
            {
                string username = pcurrentBuyer.readUsername();
                for (int i = 0; i < list_of_buyers.Count;i++)
                {
                    if(list_of_buyers.ElementAt(i).getUsername() == username)
                    {
                        compBuyer = list_of_buyers.ElementAt(i);
                        buyer = true;
                    }
                }
                if (!buyer)
                {
                    error(ref pcurrentBuyer, ref pcurrentSeller);
                }
                if (compBuyer.checkPassword(username, pcurrentBuyer.readPassword()))
                {
                    pcurrentBuyer = compBuyer;
                }
            }
            return pcurrentBuyer;
        }

        public Seller logonSeller(ref Buyer pcurrentBuyer, ref Seller pcurrentSeller)
        {
            ///////////////////////////////
            // Created By Joshua Phelan
            // Done to seperate user logon
            // into smaller functions to  
            // reudce code
            ///////////////////////////////
            bool seller = false;
            Seller compSeller = new Seller();
            while (!seller)
            {
                string username = pcurrentSeller.readUsername();
                for (int i = 0; i < list_of_sellers.Count; i++)
                {
                    if (list_of_sellers.ElementAt(i).getUsername() == username)
                    {
                        compSeller = list_of_sellers.ElementAt(i);
                        seller = true;
                    }
                }
                if (!seller)
                {
                    error(ref pcurrentBuyer, ref pcurrentSeller);
                }
                if (compSeller.checkPassword(username, pcurrentSeller.readPassword()))
                {
                    pcurrentSeller = compSeller;
                }
            }
            return pcurrentSeller;
        }

        public void saveUsers(List<Buyer> plist_of_buyers, List<Seller> plist_Of_sellers)
        {
            // Will save the usres to different files
        }

        public void error(ref Buyer pcurrentBuyer, ref Seller pcurrentSeller) //LOGIN ERROR
        {
            ///////////////////////////////
            // Written By Ryan Williams
            // Done to give feedback to the
            // user if data entered invalid
            ///////////////////////////////
            Console.WriteLine("ERROR, username or password is incorrect, try again!"); //PRINT TO SCREEN IF PASSWORD IS INCORRECT
            Console.ReadLine();
            logonUser(ref pcurrentBuyer, ref pcurrentSeller);
        }

        /// <summary>
        /// Similar to the Logon user as it uses 2 smaller functions
        /// to create a buyer or a seller
        /// </summary>
        /// <param name="pstorage"></param>
        /// <param name="pcurrentBuyer"></param>
        /// <param name="pcurrentSeller"></param>
        public void createUser(ref Buyer pcurrentBuyer, ref Seller pcurrentSeller, ref Auction_System pstorage)
        {
            ///////////////////////////////
            // Created by Joshua Phelan
            // to allow stored useres
            // entry into the system
            // was divised with the help
            // of Ryan's Menu
            ///////////////////////////////+
            string choice;
            bool valid_choice = false;
            while (!valid_choice)
            {
                Console.Clear();
                Console.WriteLine("Welcome User!");
                Console.WriteLine();
                Console.WriteLine("Buyer(b/B) or Seller(s/S)?");
                choice = Console.ReadLine();
                if (choice == "s" || choice == "S" || choice == "b" || choice == "B")
                    valid_choice = true;
                switch (choice) //Switch menu
                {
                    case "s":
                        pcurrentSeller = createSeller(ref pstorage);
                        break;
                    case "S":
                        pcurrentSeller = createSeller(ref pstorage);
                        break;
                    case "b":
                        pcurrentBuyer = createBuyer(ref pstorage);
                        break;
                    case "B":
                        pcurrentBuyer = createBuyer(ref pstorage);
                        break;
                    default:
                        Console.WriteLine("Invalid Input");
                        Console.ReadLine();
                        break;
                }

            }
            Console.WriteLine("Press ESC to return to auction menu");
            while (Console.ReadKey().Key != ConsoleKey.Escape) { }
        }

        public Seller createSeller(ref Auction_System pstorage)
        {
            /////////////////////////////////////
            // Created By Joshua Phelan
            // Done to seperate user creation
            // into smaller functions to reudce 
            // code
            /////////////////////////////////////
            User newUser = new User();
            Seller newSeller = new Seller(newUser.readUsername(), newUser.readPassword());
            pstorage.addSeller(newSeller);
            return newSeller;
        }

        /// <summary>
        /// Written by Ryan Williams
        /// Used to return the list of auctions to help 
        /// with creating, and bidding on auctions
        /// Also may play a role in the thread
        /// </summary>
        /// <returns></returns>
        public List<Auction> getList()
        {
            return list_of_auctions;
        }

        public Buyer createBuyer(ref Auction_System pstorage)
        {
            /////////////////////////////////////
            // Created By Joshua Phelan
            // Done to seperate user creation
            // into smaller functions to reudce 
            // code
            /////////////////////////////////////
            User newUser = new User();
            Buyer newBuyer = new Buyer(newUser.readUsername(), newUser.readPassword());
            pstorage.addBuyer(newBuyer);
            return newBuyer;
        }

        /// <summary>
        /// Hard coded data for system testing 
        /// </summary>
        public void populateSystem()
        {
            ///////////////////////////////////////////////////
            // Created by Joshua Phelan and Ryan Williams
            // Data created by Ryan, Function created by Josh
            // Data has been hard coded then transfered to 
            // a function that will run on system start to 
            // populate the system with data
            ////////////////////////////////////////////////

            Buyer newBuyer = new Buyer("Glyn", "NastyAuction123");
            Buyer newBuyer2 = new Buyer("Josh", "beniryu5");
            Buyer newBuyer3 = new Buyer("Ryan", "Kill-A-Bit1");
            addBuyer(newBuyer);
            addBuyer(newBuyer2);
            addBuyer(newBuyer3);

            Seller newSeller = new Seller("Rick", "rickystar");
            Seller newSeller2 = new Seller("Jared","meow2311");
            Seller newSeller3 = new Seller("Bri","isboss");
            addSeller(newSeller);
            addSeller(newSeller2);
            addSeller(newSeller3);

            Auction newAuction = new Auction("Item = Laptop", 100.00, 50.00, DateTime.Now.AddMinutes(5.0f));
            newAuction.setState(AuctionState.Running);
            Auction newAuction2 = new Auction("Item = PS4", 150.00, 100.00, DateTime.Now.AddMinutes(2.0f));
            newAuction2.setState(AuctionState.Running);
            Auction newAuction3 = new Auction("Item = Mobile Phone", 200.00, 100.00, DateTime.Now.AddMinutes(7.0f));
            newAuction3.setState(AuctionState.Running);
            addAuction(newAuction3);
            addAuction(newAuction2);
            addAuction(newAuction);
        }

        public void DisplayMenu(Auction_System pstorage)
        {
            ////////////////////////////////////////////////
            // Written By Ryan Williams and Joshua Phelan
            // Initile Menu written by Ryan, Funcionality Added by Josh
            // Basic Interactive Menu using User entry to
            // allow interaction, while the functionality
            // makes use of references to the classes to maintain
            // the data across the system
            ////////////////////////////////////////////////
            Buyer currentBuyer = new Buyer();
            Seller currentSeller = new Seller();
            string choice;
            Thread closingThread = new Thread(() => closeThread(ref pstorage));
            closingThread.Start();
     
            //Display main menu auction options
            Console.Clear();
            Console.WriteLine("--AUCTION SYSTEM--");
            Console.WriteLine();
            Console.WriteLine("1. LOGON");
            Console.WriteLine("2. BROWSE AUCTIONS");
            Console.WriteLine("3. SELL");
            Console.WriteLine("4. CREATE USER");
            Console.WriteLine("5. EXIT");
            Console.WriteLine();
            Console.WriteLine("Choose Option: ");

            choice = Console.ReadLine();

            //loop condition
            while (choice != "5")
            {
                switch (choice) //Switch menu
                {
                    case "1":
                        pstorage.logonUser(ref currentBuyer, ref currentSeller);
                        if (currentBuyer.getUsername() != null)
                            currentBuyer.buyerMenu(pstorage, currentBuyer);
                        else if (currentSeller.getUsername() != null)
                            currentSeller.sellerMenu(pstorage, ref currentSeller);
                        else
                            Console.WriteLine("Failed to Logon - Please Contact Your Supervisor");
                        DisplayMenu(pstorage);
                        break;
                    case "2":
                        pstorage.BrowseAuction();
                        DisplayMenu(pstorage);
                        break;
                    case "3":
                        currentSeller = pstorage.logonSeller(ref currentBuyer, ref currentSeller);
                        pstorage.SetupAuction(ref currentSeller);
                        DisplayMenu(pstorage);
                        break;
                    case "4":
                        pstorage.createUser(ref currentBuyer, ref currentSeller, ref pstorage);
                        DisplayMenu(pstorage);
                        break;
                    case "5":   //exit program
                    default:
                        {
                            Console.WriteLine("Invalid selection. Please pick another option: ");
                            Console.ReadLine();
                            Console.Clear();
                            DisplayMenu(pstorage);
                            break;
                        }//end default

                }//end switch case

                //return back to menu when user has picked option
                DisplayMenu(pstorage);
                choice = Console.ReadLine();
            }
        }
        /// <summary>
        /// Thread Created By Joshua Phelan
        /// Thread was written inside an infinte loop
        /// so that the thread will continuously run without stopping
        /// this was done due to difficulty implementing a timer and
        /// threads not liking functions that require parameters
        /// </summary>
        /// <param name="pstorage"></param>
        public void closeThread(ref Auction_System pstorage)
        {
          Auction newAuction = new Auction();
          Auction listAuction = new Auction();
          int i = 0;
          while (i == 0)
          {
              for (int j = 0; j < pstorage.getList().Count(); j++)
              {
                  listAuction = pstorage.getList().ElementAt(i);
                  if (listAuction.getCloseDate() <= DateTime.Now)
                  {
                      if (listAuction.getState() != AuctionState.Closed)
                      {
                          Console.WriteLine();
                          listAuction.outputAuction();
                          Console.WriteLine("The Previous Has Closed");
                          if (listAuction.numberBids() == 0)
                          {
                              Console.WriteLine("No Bids were made, Item not Sold");
                              Console.ReadLine();
                              Console.WriteLine();
                              Console.WriteLine("--------------------------------------------");
                              Console.WriteLine();
                              Console.WriteLine();
                          }
                          else if (listAuction.highestBid().getBid() < listAuction.getReservePrice())
                          {
                              Console.WriteLine("The Previous Has Closed");
                              Console.WriteLine("The reserve price was not met, Item not Sold");
                              Console.ReadLine();
                              Console.WriteLine();
                              Console.WriteLine("--------------------------------------------");
                              Console.WriteLine();
                              Console.WriteLine();
                          }
                          else
                          {
                              Console.WriteLine("The Previous Has Closed");
                              newAuction = listAuction;
                              string winner = newAuction.highestBid().whoBid().getUsername();
                              Buyer newBuyer = newAuction.highestBid().whoBid();
                              Console.WriteLine("The Auction was won by " + winner);
                              Console.WriteLine("With the bid of " + listAuction.highestBid().getBid());
                              newAuction.highestBid().whoBid().victory(newAuction);
                              Console.ReadLine();
                              Console.WriteLine();
                              Console.WriteLine("--------------------------------------------");
                              Console.WriteLine();
                              Console.WriteLine();
                          }
                      }
                      listAuction.close();
                  }
              }
          }  
       }
    }
}
