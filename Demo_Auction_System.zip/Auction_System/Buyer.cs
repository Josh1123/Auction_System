﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Auction_System
{
    public class Buyer : User
    {
        private List<Auction> auctionsWon = new List<Auction>();
        public Buyer()
        {
        }
        public Buyer(String pusername, String ppassword)
        {
            setUsername(pusername);
            setPassword(ppassword);
        }

        ~Buyer()
        {
           
        }
        /// <summary>
        /// Username get function called to
        /// inform the buyer of there victory has no other purpose
        /// </summary>
        public void victory(Auction pauction)
        {
            auctionsWon.Add(pauction);
        }

        public void displayVictory()
        {
            //////////////////////////////
            // Created By Joshua Phelan
            // To display auctions won 
            // by the buyer 
            //////////////////////////////
            foreach (Auction won in auctionsWon)
            {
                won.outputAuction();
            }
            Console.ReadLine();
        }

        public void buyerMenu(Auction_System pstorage,Buyer pcurrBuyer)
        {
            ///////////////////////////////
            // Written By Joshua Phelan
            // created by using Ryan Williams
            // displayMenu
            ///////////////////////////////
            String choice;
            Auction bidAuction = new Auction();
            //Display main menu auction options
            Console.Clear();
            Console.WriteLine("--Buyer Menu--");
            Console.WriteLine();
            Console.WriteLine("1. BID ON AUCTION");
            Console.WriteLine("2. VIEW WON AUCTION");
            Console.WriteLine();
            Console.WriteLine("Choose Option: ");
            choice = Console.ReadLine();

            if (choice == "1")
            {
                double bidAmount = 0.0f;
                bool valid = false;
                int bidIndex = 0;
                pstorage.BrowseAuction();
                // Allows user to pick auctoin they want to bid on depending on the auction number
                // Is a part of the extra Functionality
                while(!valid)
                {
                    Console.WriteLine("Choice Which Auction to Bid On: (e.g 1 = Auction 1....)");
                    choice = Console.ReadLine();
                    bidIndex = Convert.ToInt32(choice);
                    // if number valid and the auction is running
                    if (bidIndex <= pstorage.getList().Count && pstorage.getList().ElementAt(bidIndex).getState() == AuctionState.Running)
                        valid = true;
                    else
                        Console.WriteLine("Invalid Choice");
                }
                Console.WriteLine("-------------------------------------------------------");
                Console.WriteLine();

                valid = false;
                // Is a part of the extra Functionality
                bidAuction = pstorage.PlaceAuction(bidIndex);
                while (!valid)
                {
                    // Allows a valid bid to be made without having to re-logon in
                    // Is a part of the extra Functionality
                    Console.Clear();
                    if (bidAuction.numberBids() == 0)
                        Console.WriteLine("Please enter in you Bid Amount: (Starting Price is £" + bidAuction.getStartPrice());
                    else
                        Console.WriteLine("Please enter in you Bid Amount: (Currect bid is £" + bidAuction.highestBid().getBid());
                    bidAmount = Convert.ToDouble(Console.ReadLine());
                    if (bidAuction.numberBids() == 0)
                    {
                        if (bidAmount >= 1.1 * bidAuction.getStartPrice() && bidAmount <= 1.2 * bidAuction.getStartPrice())
                        {
                            bidAuction.placeBid(bidAmount, pcurrBuyer, DateTime.Now);
                            valid = true;
                        }
                        else
                        {
                            // Provides feedback to the user
                            Console.WriteLine("Bid is Invalid");
                            Console.WriteLine("Bid should be within 10 and 20 % increase on starting price");
                            Console.ReadLine();
                        }   
                    }
                    else
                    {
                        // Checks to see if bid is whithin 10 and 20 %
                        if (bidAmount >= bidAuction.highestBid().getBid() + (0.1 * bidAuction.getStartPrice()) && bidAmount <= bidAuction.highestBid().getBid() + (0.2 * bidAuction.getStartPrice()))
                        {
                            bidAuction.placeBid(bidAmount, pcurrBuyer, DateTime.Now);
                            valid = true;
                        }
                        else
                        {
                            Console.WriteLine("Bid is Invalid!");
                            Console.WriteLine("Bid should be within 10 and 20 % increase on starting price");
                            Console.ReadLine();
                        }
                    }
                }
                Console.WriteLine();
                Console.WriteLine("Your Bid Has Been Placed");
                Console.WriteLine();
                Console.WriteLine("Press any key to return to main menu");
                Console.ReadLine();
            }
            else if (choice == "2")
            {
                displayVictory();
            }
        }
    }
}
