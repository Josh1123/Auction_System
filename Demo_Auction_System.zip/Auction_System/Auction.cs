﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

////////////////////////////////
//        Created by 
//      Joshua Phelan
////////////////////////////////

///////////////////////////////////////
// Class created to manage all 
// Functionality of an auction
// whether bids being placed
// or craetion of the auction itself
// Note: may change for read write 
// purposses
//////////////////////////////////////


namespace Auction_System
{
    public class Auction
    {
        private Item description;
        private double startPrice;
        private double reservePrice;
        private DateTime closeDate;
        private AuctionState auctionState;
        private List<Bid> bids = new List<Bid> ();

        public Auction()
        {

        }

        /// <summary>
        /// Created By Joshua Phelan
        /// 2 Constructors are done to allow
        /// for a blank auction and also allow 
        /// for an overidden Auction constructor
        /// to allow easy creation of an Auction
        /// </summary>
        /// <param name="pdescription"></param>
        /// <param name="pstart_price"></param>
        /// <param name="preserve_price"></param>
        /// <param name="closeDate"></param>

        public Auction(string pdescription, double pstart_price, double preserve_price, DateTime closeDate)
        {
            description = new Item(pdescription);
            setStartPrice(pstart_price);
            setReservePrice(preserve_price);
            setCloseDate(closeDate);
            setState(AuctionState.Pending);            
        }

        ~Auction()
        {
            
        }

        /// <summary>
        /// Created By Joshua Phelan
        /// Function that will allow for bids to be
        /// placed on any auction
        /// </summary>
        /// <param name="pamount"></param>
        /// <param name="pwho"></param>
        /// <param name="pwhen"></param>
        public void placeBid(double pamount, Buyer pwho, DateTime pwhen)
        {
            Bid currentBid = new Bid(pamount,pwho,pwhen);
            bids.Add(currentBid);
        }

        /// <summary>
        /// numberBids will return the number of
        /// bids on the auction so far and highest
        /// bid will return the current highest bid on
        /// the auction, both functions are to help
        /// with the increment limit of 10 and 20 %
        /// </summary>
        /// <returns></returns>

        public int numberBids()
        {
            return bids.Count;
        }


        /// <summary>
        /// Written by Joshua Phelan
        /// Function to get the highest bid 
        /// that has been placed on an Auction
        /// </summary>
        /// <returns></returns>
        public Bid highestBid()
        {
            Bid highest = new Bid();
            foreach(Bid b in bids)
            {
                if (b.getBid() > highest.getBid())
                {
                    highest = b;
                }   
            }
            return highest;
        }

        public void verify()
        {
            setState(AuctionState.Running);
        }
        /// <summary>
        /// Get and set functions used while trying to keep access to a minimum
        /// Written By Joshua Phelan and Ryan Williams
        /// </summary>
        public void close()
        {
            setState(AuctionState.Closed);
        }

        public bool isBlocked()
        {
            bool blocked = false;
            if (auctionState == AuctionState.Blocked)
            {
                blocked = true;
            }
            return blocked;
        }

        public void setBlocked()
        {
            setState(AuctionState.Blocked);
        }

        public void setReservePrice(double preserve_price)
        {
            reservePrice = preserve_price;
        }

        public void setStartPrice(double pstart_price)
        {
            startPrice = pstart_price;
        }

        public void setCloseDate(DateTime pdate)
        {
            closeDate = pdate;
        }

        public DateTime getCloseDate()
        {
            return closeDate;
        }

        public double getReservePrice()
        {
            return reservePrice;
        }

        public void setState(AuctionState pstate)
        {
            auctionState = pstate;
        }
        
        public Item getItem()
        {
            return description;
        }

        public double getStartPrice()
        {
            return startPrice;
        }

        public AuctionState getState()
        {
            return auctionState;
        }

        // Function added to help with browsing of auctions
        public void outputAuction()
        {
            /////////////////////////////////////
            // Created by Joshua Phelan
            // Edited by Ryan Williams
            // to give a more friendly display
            // to the user
            /////////////////////////////////////
           Console.WriteLine(getItem().outputDesription());
           Console.WriteLine();
           Console.WriteLine("Starting Price");
           Console.WriteLine(startPrice.ToString());
           Console.WriteLine();
           Console.WriteLine("Reserve Price");
           Console.WriteLine(reservePrice.ToString());
           Console.WriteLine();
           Console.WriteLine("Expiry Date & Time");
           Console.WriteLine(closeDate.ToString());
           Console.WriteLine();
           Console.WriteLine("Auction State");
           Console.WriteLine(getState().ToString());
           Console.WriteLine("-------------------------------------");
           Console.WriteLine();
        }
    }
}
