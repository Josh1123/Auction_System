﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

////////////////////////
//     Created By
//    Joshua Phelan
////////////////////////

//////////////////////////////////
// Seller is inherited from 
// User just with a boolean
// to act as a flag for
// if they are blocked or
// not, will be used in logon
// function to restrict access
///////////////////////////////////


namespace Auction_System
{
    public class Seller : User
    {
        List<Auction> pending_auctions = new List<Auction>();
        private bool blocked;
        public Seller()
        {
        }

        public Seller(String pusername, String ppassword)
        {
            setUsername(pusername);
            setPassword(ppassword);
            SellerBlocked('n');
        }

        ~Seller()
        {
            
        }
    
        public bool isBlocked()
        {
            return blocked;
        }

        public void SellerBlocked(char pblock) // Function to act as a go between the user and the setter function to set whether the seller is blocked or not
                                               // Provides validation for user entry via use of switch case to help with usability of the system
        {
            switch (pblock)
            {
                case 'y':
                    setBlocked(true);
                    break;
                case 'Y':
                    setBlocked(true);
                    break;
                case 'b':
                    setBlocked(true);
                    break;
                case 'B':
                    setBlocked(true);
                    break;
                case 'n':
                    setBlocked(false);
                    break;
                case 'N':
                    setBlocked(false);
                    break;
                default:
                    Console.WriteLine("Invalid Entry");
                    break;
            }
        }

        public void setBlocked(bool pblocked)
        {
            blocked = pblocked;
        }

        public void addPending(Auction pauction)    // Function added so that they can have multpile pending auctions Note: Will allow for a verify all function to make all auctions active done to symplify verifing certain auctions and not others
        {
            pending_auctions.Add(pauction);
        }

        // Function that will loop through the pending auction list and verify them all then add them to the list of active actions
        public void verifyAll(ref Auction_System pstorage)
        {
            foreach(Auction pauction in pending_auctions)
            {
                pauction.setState(AuctionState.Running);
                pstorage.addAuction(pauction);
            }
        }

        public void sellerMenu(Auction_System pstorage,ref Seller pcurrentSeller)
        {
            ///////////////////////////////
            // Written By Joshua Phelan
            // created by using Ryan Williams
            // displayMenu
            ///////////////////////////////
            String choice;
            //Display main menu auction options
            Console.Clear();
            Console.WriteLine("--Seller Menu--");
            Console.WriteLine();
            Console.WriteLine("1. CREATE AUCTION");
            Console.WriteLine("2. VERIFY AUCTION");
            Console.WriteLine();
            Console.WriteLine("Choose Option: ");
            choice = Console.ReadLine();

            if (choice == "1")
            {
                pstorage.SetupAuction(ref pcurrentSeller);
            }
            else if (choice == "2")
            {
                verifyAll(ref pstorage);
            }
        }

    }
}
