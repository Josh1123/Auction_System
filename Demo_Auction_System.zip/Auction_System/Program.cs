﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

/////////////////////////////////////////////////////////////////////////////////
// Current to-do list:
////////////////////////////////////////////////////////////////////////////////


///////////////////////////////
// Entry point into the system
///////////////////////////////
namespace Auction_System
{
    class Program
    {
        static void Main(string[] args)
        {
            ///////////////////////////////
            // Written By Ryan Williams
            // Adapted by Joshua Phelan
            // to reduce code in main
            ///////////////////////////////
            Auction_System storage = new Auction_System();
            storage.populateSystem();
            storage.DisplayMenu(storage);
        }//end main 
    }
}