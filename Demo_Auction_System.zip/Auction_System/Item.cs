﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Auction_System
{
    public class Item
    {
        private string description;

        public Item(string pdescription)
        {
            //////////////////////////////
            // Written by Joshua Phelan
            // Acts as a string wrapper
            // Can be expaned for greater
            // use in the future
            //////////////////////////////
            description = pdescription;
        }

        ~Item()
        {
            
        }
        public string outputDesription()
        {
            return description;
        }
    }
}
