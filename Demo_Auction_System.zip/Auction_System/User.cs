﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


/////////////////////////////////////
// Created By Joshua Phelan
//
// Base Class to share methods
// and attributes between the buyers
// and the sellers
/////////////////////////////////////
namespace Auction_System
{
    public class User
    {
        private string username;
        private string password;

        public User()
        {
            
        }

        ~User()
        {
            
        }

        // User will not need to return the username and password so no gretter functions have been created 

        public bool checkPassword(string pusername, string ppassword)
        {
            bool userEntry = false;
            if (getUsername() == pusername)
            {
                if (password == ppassword)
                {
                    userEntry = true;
                    return userEntry;
                }
                else
                    Console.WriteLine("Invalid Password");
            }
            return userEntry;
        }

        public void setUsername(String pusername)
        {
            username = pusername;
        }

        public void setPassword(String ppassword)
        {
            password = ppassword;
        }

        /// <summary>
        /// Devised by Ryan Williams Implemented by Joshua Phelan
        /// readUsername and readPassword are functions that read user input int username and password that are then returned. 
        /// This was done to avoide repeated code for creating a buyer and creating a seller as the code is very similar just broke up 
        /// Line save 16 to the now 12 lines
        /// </summary>
        /// <returns></returns>

        public String readUsername()
        {
            string username;
            Console.WriteLine("Please enter Username: ");
            username = Console.ReadLine();
            return username;
        }

        public String readPassword()
        {
            string password;
            Console.WriteLine("Please enter Password: ");
            password = Console.ReadLine();
            return password;
        }


        /// <summary>
        /// Created By Joshua Phelan
        /// Get used in victory of auction
        /// made use in check password to reduce code
        /// No get password was used to reduce amount of access
        /// to the users password
        /// </summary>
        /// <returns></returns>
        public String getUsername()
        {
            return username;
        }
    }
}
